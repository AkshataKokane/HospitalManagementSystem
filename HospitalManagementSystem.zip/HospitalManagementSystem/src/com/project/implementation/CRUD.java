package com.project.implementation;



import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.transform.Transformers;


import com.project.dbConnection.HibernateUtil;

public class CRUD {

	 Session session = null;
	    Transaction tx = null;
	    
	  public <T extends Object> int saveObject(T object) {
	        int objectID = 0;
	        try {
	        	
	        	 session = HibernateUtil.getSessionFactory().openSession();
	        	 tx = session.beginTransaction();
	            objectID = (int) session.save(object);

	            System.out.println("Object Saved Successfuly...");
	            tx.commit();
	        } catch (Exception ex) {
	        	tx.rollback();
	            ex.printStackTrace();
	        } finally {
	        	session.close();
	        }

	        return objectID;
	    }

	
	  public <T extends Object> int UpdateObject(T object) {
	        int objectID = 0;
	        try {
	        	
	        	 session = HibernateUtil.getSessionFactory().openSession();
	        	 tx = session.beginTransaction();
	            session.update(object);
	            objectID=1;
	            System.out.println("Object Saved Successfuly...");
	            tx.commit();
	        } catch (Exception ex) {
	        	tx.rollback();
	        	objectID = 0;
	            ex.printStackTrace();
	        } finally {
	        	session.close();
	        }

	        return objectID;
	    }
	  
	  public Object getLogin(String Email, String password, String tableName) {
	        Object employee = null;
	        try {
	        	 session = HibernateUtil.getSessionFactory().openSession();
	        	 tx = session.beginTransaction();
	        	 
	            employee =  session
	                    .createQuery(
	                            "From "+tableName+" where (email= :loginEmailOrName) and password = :password")
	                    .setParameter("loginEmailOrName", Email).setParameter("password", password)
	                    .uniqueResult();
tx.commit();
	        } catch (Exception ex) {
	           tx.rollback();
	            ex.printStackTrace();
	        } finally {
	           session.close();
	        }
	        return employee;
	    }
	  
	  
	  public ResultSet getResultDetails(String query) {
		  ResultSet rs=null;
	        try {
	          
	        	Connection con=	HibernateUtil.getconnection();
	        	Statement s=con.createStatement();
	        	rs=s.executeQuery(query);
	           

	        } catch (Exception ex) {
	           
	            ex.printStackTrace();
	        } finally {
	            
	        }

	        return rs;
	    }
	  
	  
	  public int InsertDetails(String query) {
		  int i=0;
	        try {
	          
	        	Connection con=	HibernateUtil.getconnection();
	        	Statement s=con.createStatement();
	        	i=s.executeUpdate(query);
	           

	        } catch (Exception ex) {
	           
	            ex.printStackTrace();
	        } finally {
	            
	        }

	        return i;
	    }

	
}
