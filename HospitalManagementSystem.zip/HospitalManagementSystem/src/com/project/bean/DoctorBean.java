package com.project.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="DoctorRegister")
public class DoctorBean {

	@Id
	@GeneratedValue
	private int id;
	
	private String Name;
	private String dob;
	private String address;
	private String mobile;
	private String gender;
	private String email;
	private String specialization;
	private String password;
	
	
	
	
	
	public DoctorBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DoctorBean(String name, String dob, String address, String mobile, String gender, String email,
			String specialization, String password) {
		super();
		Name = name;
		this.dob = dob;
		this.address = address;
		this.mobile = mobile;
		this.gender = gender;
		this.email = email;
		this.specialization = specialization;
		this.password = password;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
	
}
