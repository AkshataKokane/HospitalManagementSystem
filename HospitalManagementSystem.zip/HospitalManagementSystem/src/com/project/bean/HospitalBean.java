package com.project.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="HospitalRegister")
public class HospitalBean {

	@Id
	@GeneratedValue
	private int id;
	
	private String Name;

	private String address;
	private String mobile;

	private String email;
	private String password;
	
	
	
	
	
	public HospitalBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public HospitalBean(String name, String address, String mobile, String email, String password) {
		super();
		Name = name;
		
		this.address = address;
		this.mobile = mobile;
		this.email = email;
		this.password = password;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
}
