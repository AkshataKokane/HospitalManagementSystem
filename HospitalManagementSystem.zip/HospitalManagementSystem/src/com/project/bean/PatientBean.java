package com.project.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="PatientRegister")
public class PatientBean {

	@Id
	@GeneratedValue
	private int id;
	
	private String Name;
	private String dob;
	private String address;
	private String mobile;
	private String gender;
	private String email;
	private String addiction;
	private String allergy;
	private String diabetic;
	private String bloodgroup;
	private String bloodPressure;
	private String disability;
	private String password;
	private String disease;
	private String speciality;
	private String medicine;
	
	
	
	public PatientBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PatientBean(String name, String dob, String address, String mobile, String gender, String email,
			String addiction, String allergy, String diabetic,String bloodgroup, String bloodPressure, String disability, String password,
			String disease, String speciality, String medicine) {
		super();
		Name = name;
		this.dob = dob;
		this.address = address;
		this.mobile = mobile;
		this.gender = gender;
		this.email = email;
		this.addiction = addiction;
		this.allergy = allergy;
		this.diabetic = diabetic;
		this.bloodgroup=bloodgroup;
		this.bloodPressure = bloodPressure;
		this.disability = disability;
		this.password = password;
		this.disease = disease;
		this.speciality = speciality;
		this.medicine = medicine;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddiction() {
		return addiction;
	}
	public void setAddiction(String addiction) {
		this.addiction = addiction;
	}
	public String getAllergy() {
		return allergy;
	}
	public void setAllergy(String allergy) {
		this.allergy = allergy;
	}
	public String getDiabetic() {
		return diabetic;
	}
	public void setDiabetic(String diabetic) {
		this.diabetic = diabetic;
	}
	public String getBloodPressure() {
		return bloodPressure;
	}
	public void setBloodPressure(String bloodPressure) {
		this.bloodPressure = bloodPressure;
	}
	public String getDisability() {
		return disability;
	}
	public void setDisability(String disability) {
		this.disability = disability;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDisease() {
		return disease;
	}
	public void setDisease(String disease) {
		this.disease = disease;
	}
	public String getSpeciality() {
		return speciality;
	}
	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}
	public String getMedicine() {
		return medicine;
	}
	public void setMedicine(String medicine) {
		this.medicine = medicine;
	}
	




	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	
	
	
	
	
	
}
