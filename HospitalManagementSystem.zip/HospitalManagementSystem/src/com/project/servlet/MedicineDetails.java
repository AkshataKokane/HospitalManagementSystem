package com.project.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.Algorithm.QRCode2;
import com.project.Algorithm.QRCodee;
import com.project.bean.DoctorBean;
import com.project.implementation.CRUD;

/**
 * Servlet implementation class MedicineDetails
 */
@WebServlet("/MedicineDetails")
public class MedicineDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MedicineDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	String medicine,pname,pid;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		HttpSession session = request.getSession();
		CRUD crud=new CRUD();
		DoctorBean bean= (DoctorBean) session.getAttribute("Doctor");
		medicine=request.getParameter("medicine");
		pid=request.getParameter("mpid");		
		pname = request.getParameter("mpname");
		
		
		try{
			
			String query="UPDATE `patientregister` SET `medicine`= '"+medicine+"' where id='"+pid+"'";
                int r=crud.InsertDetails(query);
		System.out.println("insert done");
		  
		
		query="SELECT * FROM `patientregister` where id='"+pid+"'";
               
		ResultSet rs = crud.getResultDetails(query);
		System.out.println("Getting Patient Data:"+query);
		String pdob,pgender,paddress,pmobile,pemail,paddiction,pallergy,pdisease,pspecialist,pmedicine;
		while(rs.next())
                   { 
			
                             pdob=rs.getString("dob");
                             System.out.println("Data:"+pdob);
                pgender=rs.getString("gender");
                System.out.println("pgender:"+pgender);
                
                  paddress=rs.getString("address");
                  System.out.println("paddress:"+paddress);
                  
                   pmobile=rs.getString("mobile");
                   System.out.println("pmobile:"+pmobile);
                   
                pemail=rs.getString("email");
                System.out.println("pemail:"+pemail);
                
                  paddiction=rs.getString("addiction");
                  System.out.println("paddiction:"+paddiction);
                  
                   pallergy=rs.getString("allergy");
                   System.out.println("pallergy:"+pallergy);
                   
                pdisease=rs.getString("disease");
                System.out.println("pdisease:"+pdisease);
                
                  pspecialist=rs.getString("speciality");
                  System.out.println("pspecialist:"+pspecialist);
                  
                   pmedicine=rs.getString("medicine");
                   System.out.println("pmedicine:"+pmedicine);
                   
		        String pid = rs.getString("id");
		        System.out.println("pid:"+pid);
		        
		        //session.setAttribute("pid",pid);
		      String   data = ("Name: "+pname+"\n"+"DOB: "+pdob+"\n"+"Gender: "+pgender+"\n"+"Addess: "+paddress+"\n"+"MObileNo: "+pmobile+"\n"+"EmailId: "+pemail+"\n"+"Addiction: "+paddiction+"\n"+"Allergy: "+pallergy+"\n"+"Disease:"+pdisease+"\n"+"Specialist: "+pspecialist+"\n"+"_______________________________"+"\n"+"Medicine: "+pmedicine);
		 System.out.println("Patient data is=="+data);
		 
		       
		 QRCodee qr1=new QRCodee();
                           
                             String pid1=pid+"a";
                               QRCodee.main(data,pid1);
                               
                               
			      System.out.println("First QR generated........");
			      String[] argument = new String[] {"123"};

					  System.out.println("Reaching to Second QR code........");
                               String pid2=pid+"b";
                               QRCode2.main(data,pid2);
                               
				 System.out.println("Both QR Code generated successfully");
				 response.sendRedirect("doctorHome.jsp?qrgenerated=done");
			} 
		
		}
		catch(Exception e)
		{
			
		}

		
		
		
		
	}

}
