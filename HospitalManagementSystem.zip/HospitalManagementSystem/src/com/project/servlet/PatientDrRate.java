package com.project.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.bean.PatientBean;

import com.project.implementation.CRUD;

/**
 * Servlet implementation class PatientDrRate
 */
@WebServlet("/PatientDrRate")
public class PatientDrRate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PatientDrRate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	int id;
	String pname,dmail;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		try {

			HttpSession session = request.getSession();
			PatientBean bean= (PatientBean) session.getAttribute("Patient");

			String pname=bean.getName();
			String demail=(String)session.getAttribute("dmail");
			int rate=Integer.parseInt(request.getParameter("rating"));
			
			System.out.println("Patient Name====="+pname);
			System.out.println("demail====="+demail);
			System.out.println("rating====="+rate);
			
			CRUD crud=new CRUD();
			String query="UPDATE `appliedappform` SET `rate`='"+rate+"',status='1' WHERE email='"+demail+"' and pname='"+pname+"'";
			int i=crud.InsertDetails(query);
			if(i > 0)
			{
				request.setAttribute("msg", "Rating Save Successfully");
				request.getRequestDispatcher("PatientViewAppoinment.jsp").forward(request, response);
				
			}else{
				request.setAttribute("msg", "Rating Save UN...Successfully");
				request.getRequestDispatcher("PatientViewAppoinment.jsp").forward(request, response);

			}
			
			}
		catch (Exception e)
	    {
	      System.err.println("Got an exception! ");
	      System.err.println(e.getMessage());
	    
	    }

		
	}

}
