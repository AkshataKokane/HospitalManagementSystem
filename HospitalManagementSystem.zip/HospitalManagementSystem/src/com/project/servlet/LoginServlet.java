package com.project.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.bean.DoctorBean;
import com.project.bean.HospitalBean;
import com.project.bean.MedicalBean;
import com.project.bean.PatientBean;
import com.project.implementation.CRUD;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		String type=request.getParameter("logintype");
		String email=request.getParameter("Email");
		String pass=request.getParameter("Password");
		
		CRUD crud = new CRUD();
		Object obj=null;
	HttpSession session=request.getSession();
	
		if(type.equals("Patient"))
		{
			obj=crud.getLogin(email, pass, "PatientBean");
			if(obj!=null)
			{
			PatientBean bean= (PatientBean) obj;
			session.setAttribute("Patient", bean);
			request.setAttribute("msg", "Welcome "+ email);
			request.getRequestDispatcher("PatientAppoinment.jsp").forward(request, response);
			}else{
				request.setAttribute("msg", "Login Failed ");
				request.getRequestDispatcher("Home.jsp").forward(request, response);
			}
		}else if(type.equals("Doctor"))
		{
			obj=crud.getLogin(email, pass, "DoctorBean");
			if(obj!=null)
			{
			DoctorBean bean= (DoctorBean) obj;
			session.setAttribute("Doctor", bean);
			request.setAttribute("msg", "Welcome "+ email);
			request.getRequestDispatcher("doctorHome.jsp").forward(request, response);
			}else{
				request.setAttribute("msg", "Login Failed ");
				request.getRequestDispatcher("Home.jsp").forward(request, response);
			}
			
		}else if(type.equals("Medical"))
		{
			obj=crud.getLogin(email, pass, "MedicalBean");
			if(obj!=null)
			{
			MedicalBean bean= (MedicalBean) obj;
			session.setAttribute("Medical", bean);
			request.setAttribute("msg", "Welcome "+ email);
			request.getRequestDispatcher("MedicalHome.jsp").forward(request, response);
		}else{
			request.setAttribute("msg", "Login Failed ");
			request.getRequestDispatcher("Home.jsp").forward(request, response);
		}
		
		}else if(type.equals("Hospital"))
		{
			obj=	crud.getLogin(email, pass, "HospitalBean");
			if(obj!=null)
			{
				HospitalBean bean= (HospitalBean) obj;
			session.setAttribute("Hospital", bean);
			request.setAttribute("msg", "Welcome "+ email);
			request.getRequestDispatcher("EmergencyPatient.jsp").forward(request, response);
		}else{
			request.setAttribute("msg", "Login Failed ");
			request.getRequestDispatcher("Home.jsp").forward(request, response);
		}
		
		}
		
		
		
	}

}
