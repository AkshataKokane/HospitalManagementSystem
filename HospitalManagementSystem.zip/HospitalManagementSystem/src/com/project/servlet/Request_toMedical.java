package com.project.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.project.bean.PatientBean;

import com.project.implementation.CRUD;

/**
 * Servlet implementation class Request_toMedical
 */
@WebServlet("/Request_toMedical")
public class Request_toMedical extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Request_toMedical() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session = request.getSession();
		PatientBean bean= (PatientBean) session.getAttribute("Patient");
		String b =String.valueOf(bean.getId());

		
	
		String pid = request.getParameter("pid");
		String medicalname = request.getParameter("medicalname");
		String mid = request.getParameter("mid");
		String email = request.getParameter("email");
		
//		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//		LocalDate localDate = LocalDate.now();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date  localDate=new  Date(System.currentTimeMillis());
		
		System.out.println(sdf.format(localDate));
		
		System.out.println("P id = "+pid);
		System.out.println("Medical Name ="+medicalname);
		System.out.println("M id=="+mid);
		try{
			CRUD crud=new CRUD();
			String query="SELECT * FROM `homedeliveryrequest` where pid='"+pid+"' and mid='"+mid+"' and date='"+sdf.format(localDate)+"' ";
		
		ResultSet rs1 =crud.getResultDetails(query);
		if(rs1.next()){
			response.sendRedirect("patientHome.jsp?alreadydone='done'");
		}
		else{
			
		query="INSERT INTO `homedeliveryrequest`(`id`, `pid`, `mid`, `date`) VALUES (null,'"+pid+"','"+mid+"','"+sdf.format(localDate)+"')";
		
		
		int i = crud.InsertDetails(query);
		if(i>0)
		{
			request.setAttribute("msg", "Home Delivery Successfully");
			request.getRequestDispatcher("PatientAppoinment.jsp").forward(request, response);
			
		}
		else{
			request.setAttribute("msg", "Home Delivery UN..Successfully");
			request.getRequestDispatcher("PatientAppoinment.jsp").forward(request, response);
		}
		}
		}
		catch(Exception e){}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
		
	}

}
