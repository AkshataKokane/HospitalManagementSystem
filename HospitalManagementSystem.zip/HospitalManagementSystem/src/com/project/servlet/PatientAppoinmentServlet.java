package com.project.servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.zxing.NotFoundException;
import com.google.zxing.WriterException;
import com.project.Algorithm.QRCode2;
import com.project.bean.PatientBean;
import com.project.implementation.CRUD;

/**
 * Servlet implementation class PatientAppoinmentServlet
 */
@WebServlet("/PatientAppoinmentServlet")
public class PatientAppoinmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PatientAppoinmentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		String dob=request.getParameter("date");
		String disease=request.getParameter("disease");
		String specialist=request.getParameter("specialist");
		
		HttpSession session=request.getSession();
		session.setAttribute("apooinmentDate", dob);
		PatientBean bean= (PatientBean) session.getAttribute("Patient");
		bean.setDisease(disease);
		bean.setSpeciality(specialist);
		
		CRUD crud=new CRUD();
		crud.UpdateObject(bean);
		
		String query="INSERT INTO patientappoinment (pid,date,disease) VALUES ('"+bean.getId()+"', '"+dob+"', '"+disease+"') ";
		crud.InsertDetails(query);
		
		query="SELECT * FROM patientappoinment where pid='"+bean.getId()+"'";
		ResultSet rs =crud.getResultDetails(query);
		try {
			while (rs.next()) {
				 
				// disease1= rs.getString("disease");
				
				disease= disease.concat(rs.getString("disease")+" - "+rs.getString("date") +" ,"+"\n");
				
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String data = ("Id: "+bean.getId()+"\n"+"Name: "+bean.getName()+"\n"+"Email: "+bean.getEmail()+"\n"+"Mob.No: "+bean.getMobile()+"\n"+"DOB: "+bean.getDob()+"\n"+"Gender: "+bean.getGender()+"\n"+"Address: "+bean.getAddress()+"\n"+"Addiction: "+bean.getAddiction()+"\n"+"Allergy: "+bean.getAllergy()+"\n"+"Disease: "+disease);

		  try {
			QRCode2.main(data,String.valueOf(bean.getId()));
			
			 com.project.Algorithm.Java_sms_httprequest  sms=new com.project.Algorithm.Java_sms_httprequest();
             sms.sendSms(bean.getMobile());
		response.sendRedirect("viewpatientqrcode.jsp?accept=yes");
			
		} catch (NotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (WriterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
