package com.project.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.bean.PatientBean;
import com.project.implementation.CRUD;

/**
 * Servlet implementation class PatientRegisterServlet
 */
@WebServlet("/PatientRegisterServlet")
public class PatientRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PatientRegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	String fname,dob,address,mbno,gender,email,addiction,allergy,diabetic,bloodgroup,bloodpressure,disability,pwd;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
		fname=request.getParameter("fname");
		System.out.println("First Name=="+fname);
		
		dob=request.getParameter("dob");
		
	
		gender=request.getParameter("gender");
		System.out.println("gender=="+gender);
		address=request.getParameter("address");
		System.out.println("address=="+address);
		mbno=request.getParameter("mbnumber");
		System.out.println("Mobile No=="+mbno);
		email=request.getParameter("email");
		
		System.out.println("Email=="+email);
		addiction=request.getParameter("addiction");
		System.out.println("addiction===="+addiction);
		allergy=request.getParameter("allergy");
		System.out.println("allergy==="+allergy);
		 bloodgroup = request.getParameter("bloodgroup");
		 diabetic = request.getParameter("diabetic");
		 bloodpressure = request.getParameter("bloodpressure");
		 disability = request.getParameter("disability");
		
		 pwd=request.getParameter("pwd");
		System.out.println("Password=="+pwd);
		
		
		PatientBean bean=new PatientBean(fname,dob,address,mbno,gender,email,addiction,allergy,diabetic,bloodgroup,bloodpressure,disability,pwd,"","","");
		
		CRUD crud=new CRUD();
		 int objectID=crud.saveObject(bean);
		if(objectID > 0)
		{
			request.setAttribute("msg", "Register Successfully");
			request.getRequestDispatcher("Home.jsp").forward(request, response);
			
		}else{
			request.setAttribute("msg", "Register UN..Successfully");
			request.getRequestDispatcher("Home.jsp").forward(request, response);
		}
		
		
	}

}
