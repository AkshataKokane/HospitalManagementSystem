package com.project.servlet;

import java.io.IOException;
import java.sql.Date;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.project.implementation.CRUD;

/**
 * Servlet implementation class AdmitPatientServlet
 */
@WebServlet("/AdmitPatientServlet")
public class AdmitPatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdmitPatientServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    String hid,pid;
	Date admitDate,dischargeDate;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 hid=request.getParameter("hid");
		 pid=request.getParameter("pid");
		admitDate=new Date(System.currentTimeMillis());
		dischargeDate=new Date(System.currentTimeMillis());
		
try{
	CRUD crud=new CRUD();
			String query="INSERT INTO admitpatient (id, hid, pid, admitDate, dischargeDate, dischargeStatus) VALUES (NULL, '"+hid+"',  '"+pid+"', '"+admitDate+"', '"+dischargeDate+"', false)";
			int r=crud.InsertDetails(query);
		System.out.println("insert done");
		
		
		
		if(r>0) 
			{
			
			request.setAttribute("msg", "Admit Patient Successfully");
			request.getRequestDispatcher("HospitalList.jsp").forward(request, response);
			
		      
			} 
		else 
			{
			
			request.setAttribute("msg", "Admit Patient UN..Successfully");
			request.getRequestDispatcher("HospitalList.jsp").forward(request, response);
			
			
	       
			}
		
		}
		catch(Exception e)
		{
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	doGet(request, response);
		
		
		
		
	}

}
