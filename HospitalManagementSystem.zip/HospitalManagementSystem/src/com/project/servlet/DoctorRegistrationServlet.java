package com.project.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.bean.DoctorBean;
import com.project.bean.PatientBean;
import com.project.implementation.CRUD;

/**
 * Servlet implementation class DoctorRegistrationServlet
 */
@WebServlet("/DoctorRegistrationServlet")
public class DoctorRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoctorRegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	String fname,dob,address,mbno,gender,email,specialization,pwd;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
		fname=request.getParameter("fname");
		System.out.println("First Name=="+fname);
		
		dob=request.getParameter("dob");
		
	
		gender=request.getParameter("gender");
		System.out.println("gender=="+gender);
		address=request.getParameter("address");
		System.out.println("address=="+address);
		mbno=request.getParameter("mbnumber");
		System.out.println("Mobile No=="+mbno);
		email=request.getParameter("email");
		specialization=request.getParameter("speciality");
		
		
		 pwd=request.getParameter("pwd");
		System.out.println("Password=="+pwd);
		
		
		DoctorBean bean=new DoctorBean(fname,dob,address,mbno,gender,email,specialization,pwd);
		
		CRUD crud=new CRUD();
		 int objectID=crud.saveObject(bean);
		if(objectID > 0)
		{
			request.setAttribute("msg", "Register Successfully");
			request.getRequestDispatcher("Home.jsp").forward(request, response);
			
		}else{
			request.setAttribute("msg", "Register UN..Successfully");
			request.getRequestDispatcher("Home.jsp").forward(request, response);
		}

		
	}

}
