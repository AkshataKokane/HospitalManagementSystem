/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.project.dbConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;


public class HibernateUtil {
	private static final SessionFactory sessionFactory;
	static {
		try {
//			sessionFactory = new Configuration().configure()
//					.buildSessionFactory();
                        // sessionFactory= new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();
                       // sessionFactory= new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
                        Configuration cf=new AnnotationConfiguration().configure("hibernate.cfg.xml");
                         sessionFactory=cf.buildSessionFactory();
                        System.out.println("Connection Establish");
                } catch (Throwable ex) {
			System.err.println("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

          public static Connection getconnection()
        {
             Connection con =null;
           try{
                Class.forName("com.mysql.jdbc.Driver");
         con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/HospitalQR", "root", "root");
           }catch(Exception e)
           {
               e.printStackTrace();
           }
           
           return con;
        }
        
      public static void main(String[] args)
      {
          HibernateUtil.getSessionFactory();
      }
}

