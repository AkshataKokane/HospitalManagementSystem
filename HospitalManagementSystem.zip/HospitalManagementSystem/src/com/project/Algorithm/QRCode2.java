package com.project.Algorithm;


//import org.apache.catalina.connector.Request;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpSession;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.NotFoundException;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.project.dbConnection.DbConnection;

public class QRCode2 {
	
	
	static String data;
	public String service(HttpSession sess )
	{
		//HttpSession sess = req.getSession();
		String pid = (String)sess.getAttribute("pid");
		System.out.println("Patient ID=="+pid);
		String username = (String)sess.getAttribute("fname");
		String Email = (String)sess.getAttribute("Email");
		String mobile = (String)sess.getAttribute("mobile");
		String dob = (String)sess.getAttribute("dob");
		String gender = (String)sess.getAttribute("gender");
		String address = (String)sess.getAttribute("address");
		String addiction = (String)sess.getAttribute("addiction");
		String allergy = (String)sess.getAttribute("allergy");
		String disease="";
		
		/*Connection con = DbConnection.getConnection();
		//PreparedStatement ps = con.prepareStatement("SELECT * FROM patientdiseases where uid='"+pid+"'");
		PreparedStatement ps =con.prepareStatement("SELECT * FROM patientdiseases where uid='"+pid+"'");
		//ps.setString(1, username);
		//ps.setString(2, password);
*/
		try{
		Connection con = DbConnection.getConnection();
		java.sql.PreparedStatement ps = con.prepareStatement("SELECT * FROM patientdiseases where pid='"+pid+"'");
		
		
		
		ResultSet rs = ps.executeQuery();
		
		String disease1="";
		while (rs.next()) {
		 
		// disease1= rs.getString("disease");
		
		disease= disease.concat(rs.getString("disease")+" - "+rs.getString("date") +" ,"+"\n");
		
		}
		System.out.println("Patient Disease=="+disease);
		
		ps.close();
	} catch (Exception e) {
		e.printStackTrace();
	}
		 System.out.println("Patient All Disease is=="+disease);
		 data = ("Id: "+pid+"\n"+"Name: "+username+"\n"+"Email: "+Email+"\n"+"Mob.No: "+mobile+"\n"+"DOB: "+dob+"\n"+"Gender: "+gender+"\n"+"Address: "+address+"\n"+"Addiction: "+addiction+"\n"+"Allergy: "+allergy+"\n"+"Disease: "+disease);
		 System.out.println("The Data is=="+data);
		 return data;
		
		
	}
	
	public static void main(String a, String b) throws WriterException, IOException,
	NotFoundException {


QRCode2 qr = new QRCode2();
//qr.service(req, res);
System.out.println("Test........");
String qrCodeData = a;
System.out.println("The Data is:"+data);
String filePath1 = "D:\\QRCode\\";
//String filePath1=System.getProperty("user.dir");
//filePath1=filePath1+"/QRCode";
            System.out.println("filePath1:"+filePath1);
if(!new File(filePath1).isDirectory())
{
    new File(filePath1).mkdirs();
}
String filePath = filePath1+"\\"+b+".png";
String charset = "UTF-8"; // or "ISO-8859-1"
Map<EncodeHintType, ErrorCorrectionLevel> hintMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();
hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);

createQRCode(qrCodeData, filePath, charset, hintMap, 200, 200);
System.out.println("QR Code image created successfully!");

try {
	System.out.println("Data read from QR Code: "
			+ readQRCode(filePath, charset, hintMap));
} catch (ReaderException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
System.out.println(filePath);

}
	
	public static void createQRCode(String qrCodeData, String filePath,
			String charset, Map hintMap, int qrCodeheight, int qrCodewidth)
			throws WriterException, IOException {
		/*BitMatrix matrix = new MultiFormatWriter().encode(
				new String(qrCodeData.getBytes(charset), charset),
				BarcodeFormat.QR_CODE, qrCodewidth, qrCodeheight, hintMap);
*/		
		
		BitMatrix matrix = new MultiFormatWriter().encode(
				new String(qrCodeData.getBytes(charset), charset),
				BarcodeFormat.QR_CODE, qrCodewidth, qrCodeheight);
		
		
		MatrixToImageWriter.writeToFile(matrix, filePath.substring(filePath
				.lastIndexOf('.') + 1), new File(filePath));
	}

	public static String readQRCode(String filePath, String charset, Map hintMap)
			throws FileNotFoundException, IOException, NotFoundException {
		BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(
				new BufferedImageLuminanceSource(
						ImageIO.read(new FileInputStream(filePath)))));
	/*	Result qrCodeResult = new MultiFormatReader().decode(binaryBitmap,
				hintMap);*/
		Result qrCodeResult = new MultiFormatReader().decode(binaryBitmap);
		return qrCodeResult.getText();
	}

}
