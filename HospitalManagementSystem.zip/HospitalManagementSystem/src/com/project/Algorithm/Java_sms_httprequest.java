package com.project.Algorithm;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class Java_sms_httprequest {

	public static void main(String[] args) {
		Java_sms_httprequest sms=new Java_sms_httprequest();
		sms.sendSms("9011207690");
		
		
		}
        
        
        
        
        public void sendSms(String mobile)
        {
            try {
		String recipient = "9011207690";
		String msg = "QRGenerated";
		String username = "VIMARJ";
		String password = "123456";
		String originator = "+9011207690";
		/*String requestUrl  = "http://www.miracleinfotech.in/SMSAPI?src=sendmessage&" +
		 "username=" + URLEncoder.encode(username, "UTF-8") +
		 "&password=" + URLEncoder.encode(password, "UTF-8") +
		 "&recipient=" + URLEncoder.encode(recipient, "UTF-8") +
		 "&messagetype=SMS:TEXT" +
		 "&messagedata=" + URLEncoder.encode(message, "UTF-8") +
		 "&originator=" + URLEncoder.encode(originator, "UTF-8") +
		 "&serviceprovider=GSMModem1" +
		 "&responseformat=html";*/
		
//		 String url1 = "http://www.miracleinfotech.in/SMSAPI?" +
//                 
//                 "&dst=" + originator +
//                 "&msg=" + URLEncoder.encode(message, "UTF-8")+
//                 "&username=" + URLEncoder.encode(username, "UTF-8") +
//                 "&password=" + password;
		 //String komal = "http://www.miracleinfotech.in/SMSAPI?user=VIMARJ&pass=123456&channel=Trans&number="+mobile+"&message="+msg+"&SenderID=VIMARJ&Campaign=XYZ";

               String  komal="https://www.fast2sms.com/dev/bulk?authorization=wOKVQs9cSXCW68J2MFlqvBghPafumD3Noy1YbZitkr5RjxHGETKdQJ0yb1OM3NH8vj5i42et79FonUDa&sender_id=FSTSMS&message=QR%20Code%20is%20generated&language=english&route=p&numbers="+mobile;;
//String komal="https://www.fast2sms.com/dev/bulk?authorization=wOKVQs9cSXCW68J2MFlqvBghPafumD3Noy1YbZitkr5RjxHGETKdQJ0yb1OM3NH8vj5i42et79FonUDa&sender_id=FSTSMS&message=This%20is%20a%20test%20message&language=english&route=p&numbers=9011207690,7768960339";;
//j
//DESKTOP-TBO8TQP (22:55): String komal="https://www.fast2sms.com/dev/bulk?authorization=wOKVQs9cSXCW68J2MFlqvBghPafumD3Noy1YbZitkr5RjxHGETKdQJ0yb1OM3NH8vj5i42et79FonUDa&sender_id=FSTSMS&message=QR%20Code%20is%20Generated&language=english&route=p&numbers='"+mobile+"'";;

                 
                    System.out.println("komal:"+komal);

		URL url = new URL(komal);
		HttpURLConnection uc = (HttpURLConnection)url.openConnection();
		System.out.println(uc.getResponseMessage());
		uc.disconnect();
		} catch(Exception ex) {
		System.out.println(ex.getMessage());
		}
		
        }
	
}
