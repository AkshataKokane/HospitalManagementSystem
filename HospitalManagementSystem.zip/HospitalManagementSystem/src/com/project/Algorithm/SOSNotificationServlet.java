package com.project.Algorithm;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class SOSNotificationServlet
 */
@WebServlet("/SOSNotificationServlet")
public class SOSNotificationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SOSNotificationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    Connection con = null;
	PreparedStatement ps;
	ResultSet rs;
	String fname,mname,lname,dob,gender,address,mbno,email,addiction,allergy;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String eid=request.getParameter("eid");
		String hid=request.getParameter("hid");
		
try{
			
			con = DbConnection.getConnection();
		Statement st = con.createStatement();
		System.out.println("test1");
		
		int r=st.executeUpdate("UPDATE `emergencypatient` SET `hospitalId`='"+hid+"' WHERE id='"+eid+"' ");
		System.out.println("Updation done");
		
		if(r>0) 
			{
		        System.out.println("Updation Successfull");
				 response.sendRedirect("patientHome.jsp?update=done");
			} 
		else 
			{
	        System.out.println("Updation  Unsuccessfull");
	        response.sendRedirect("patientHome.jsp?fail=yes");
			}
		
		}
		catch(Exception e)
		{
			
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
