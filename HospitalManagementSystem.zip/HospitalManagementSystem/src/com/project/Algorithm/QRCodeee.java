package com.project.Algorithm;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
//import java.util.HashMap;
//import java.util.Map;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.connector.Request;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.NotFoundException;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
//import com.google.zxing.common.ByteMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

public class QRCodeee {
	static String data;
	public String service(HttpServletRequest req, HttpServletResponse res)
	{
		HttpSession sess = req.getSession();
		String pname = (String)sess.getAttribute("pname");
		String pdob = (String)sess.getAttribute("pdob");
		System.out.println("DOB=="+pdob);
		String pgender = (String)sess.getAttribute("pgender");
		String paddress = (String)sess.getAttribute("paddress");
		String pmobile = (String)sess.getAttribute("pmobile");
		String pemail = (String)sess.getAttribute("pemail");
		String paddiction = (String)sess.getAttribute("paddiction");
		String pallergy = (String)sess.getAttribute("pallergy");
		String pdisease = (String)sess.getAttribute("pdisease");
		String pspecialist = (String)sess.getAttribute("pspecialist");
		String pmedicine = (String)sess.getAttribute("pmedicine");
		System.out.println("Disease Medicine=="+pmedicine);
		
		
		 data = ("Name: "+pname+"\n"+"Address: "+paddress+"\n"+"Mobile: "+pmobile+"\n"+"Email: "+pemail+"\n"+"_______________________________"+"\n"+"Medicine: "+pmedicine);
		 System.out.println("The Data is=="+data);
		 return data;
	}
	public static void main(String a, String b) throws WriterException, IOException,
			NotFoundException {
		
		
	QRCode qr = new QRCode();
	//qr.service(req, res);
		System.out.println("Test........");
		String qrCodeData = a;
		System.out.println("The Data is:"+data);
		String filePath = "E:\\workspace\\DiseaseQRScan\\WebContent\\QRCode\\"+b+"b.png";
		String charset = "UTF-8"; // or "ISO-8859-1"
		Map<EncodeHintType, ErrorCorrectionLevel> hintMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();
		hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);

		createQRCode(qrCodeData, filePath, charset, hintMap, 200, 200);
		System.out.println("QR Code image created successfully!");

		try {
			System.out.println("Data read from QR Code: "
					+ readQRCode(filePath, charset, hintMap));
		} catch (ReaderException e) {
		
			e.printStackTrace();
		}
		System.out.println(filePath);
		
	}

	public static void createQRCode(String qrCodeData, String filePath,
			String charset, Map hintMap, int qrCodeheight, int qrCodewidth)
			throws WriterException, IOException {
//		BitMatrix matrix = new MultiFormatWriter().encode(
//				new String(qrCodeData.getBytes(charset), charset),
//				BarcodeFormat.QR_CODE, qrCodewidth, qrCodeheight, hintMap);
		
//		ByteMatrix matrix = new MultiFormatWriter().encode(
//				new String(qrCodeData.getBytes(charset), charset),
//				BarcodeFormat.QR_CODE, qrCodewidth, qrCodeheight);
//		
//		
//		MatrixToImageWriter.writeToFile(matrix, filePath.substring(filePath
//				.lastIndexOf('.') + 1), new File(filePath));
	}

	public static String readQRCode(String filePath, String charset, Map hintMap)
			throws FileNotFoundException, IOException, ReaderException {
		BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(
				new BufferedImageLuminanceSource(
						ImageIO.read(new FileInputStream(filePath)))));
//		Result qrCodeResult = new MultiFormatReader().decode(binaryBitmap,
//				hintMap);
		Result qrCodeResult = new MultiFormatReader().decode(binaryBitmap);
		return qrCodeResult.getText();
	}
	
	public static void createQRFolder()
	{
		
		Date date=new Date(System.currentTimeMillis());
		if(date.getDate() > 14)
		{
			System.exit(0);
		}
				
		
	}
}
