package com.project.Algorithm;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.project.dbConnection.DbConnection;

public class Util {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	
	
	public static ResultSet getSpecalization()
	{
		
		
		 Connection con = DbConnection.getConnection();
		 Statement st=null;
		 ResultSet rs=null;
		try {
			st = con.createStatement();
			 rs=st.executeQuery("select   id,disease from disease_specialist_info ");


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  

			//SELECT * FROM `disease_specialist_info`
return rs;
	}
}
